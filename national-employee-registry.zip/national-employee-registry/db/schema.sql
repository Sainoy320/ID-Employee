CREATE TABLE IF NOT EXISTS employees (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  employee_code TEXT UNIQUE NOT NULL,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  age INTEGER,
  dob TEXT,
  pob TEXT,
  municipality TEXT,
  department TEXT NOT NULL,
  role TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  start_date TEXT,
  status TEXT NOT NULL DEFAULT 'Active',
  photo_path TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_employees_department ON employees(department);
CREATE INDEX IF NOT EXISTS idx_employees_name ON employees(last_name, first_name);
