const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");

const dataDir = path.join(__dirname, "..", "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const dbPath = path.join(dataDir, "registry.db");
const db = new Database(dbPath);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

const schema = fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8");
db.exec(schema);

// Seed a handful of sample records the first time the database is created,
// so the dashboard isn't empty on first run. Safe to delete any time.
const count = db.prepare("SELECT COUNT(*) AS n FROM employees").get().n;
if (count === 0) {
  const seed = db.prepare(`
    INSERT INTO employees
      (employee_code, first_name, last_name, department, role, phone, email, start_date, status)
    VALUES (@employee_code, @first_name, @last_name, @department, @role, @phone, @email, @start_date, @status)
  `);
  const samples = [
    { employee_code: "GOV-0012", first_name: "David", last_name: "Vance", department: "Ministry of Interior & Civil Affairs", role: "Director of Logistics", phone: "+1 202 555 0148", email: "d.vance@gov.example", start_date: "2014-08-12", status: "Active" },
    { employee_code: "GOV-0489", first_name: "Maria", last_name: "Santos", department: "Department of State", role: "Foreign Service Officer", phone: "+1 202 555 0199", email: "m.santos@gov.example", start_date: "2019-02-28", status: "Active" },
    { employee_code: "GOV-1023", first_name: "Sarah", last_name: "Jenkins", department: "Treasury Department", role: "Research Analyst", phone: "+1 202 555 0122", email: "s.jenkins@gov.example", start_date: "2008-11-04", status: "Active" },
  ];
  const insertMany = db.transaction((rows) => rows.forEach((r) => seed.run(r)));
  insertMany(samples);
}

module.exports = db;
