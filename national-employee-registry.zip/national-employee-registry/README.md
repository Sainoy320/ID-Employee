# National Employee Registry

A real, working version of the mockup: Node.js + Express backend, SQLite
database, session-based admin login, and photo uploads — wired up to the
original login / add-employee / dashboard pages.

## What changed from the mockup

- **Login** now checks a real password (hashed with bcrypt) and creates a
  server-side session, instead of just linking to the next page.
- **Add Employee** submits to a real API, saves to SQLite, and handles
  photo uploads. It also doubles as the **Edit Employee** page.
- **Dashboard** loads live data: real search, department filter,
  pagination, stats, CSV export, and delete — all backed by the database.
- Every page (except the login page itself) checks for a valid session and
  redirects to sign-in if you're not logged in.

## 1. Install dependencies

```bash
npm install
```

## 2. Configure your admin login

Copy the example env file:

```bash
cp .env.example .env
```

Generate a password hash (you'll be prompted to type a password):

```bash
npm run set-password
```

Copy the `ADMIN_PASSWORD_HASH=...` line it prints into your `.env` file.
Also set `ADMIN_USERNAME` in `.env` if you don't want the default `admin`,
and replace `SESSION_SECRET` with a random string (the command to generate
one is in `.env.example`).

## 3. Run it

```bash
npm start
```

Visit **http://localhost:3000**, sign in with the username/password you just
set, and you're in. The database file is created automatically at
`data/registry.db` the first time you run the server, seeded with a few
sample employees so the dashboard isn't empty.

## Project structure

```
server.js              Express app entry point
routes/auth.js          Login / logout / session check
routes/employees.js     Employee CRUD, search, stats, CSV export, photo upload
middleware/requireAuth.js  Blocks API access without a valid session
db/schema.sql           SQLite table definition
db/database.js          Opens the DB, runs the schema, seeds sample data
public/                 The original front-end pages, now calling the API
data/registry.db         SQLite database file (created on first run)
public/uploads/          Uploaded employee photos
```

## Notes for going further

- **Sessions** currently use Express's default in-memory store, which is
  fine for one admin on one server but is wiped on restart and doesn't
  work across multiple server instances. If you deploy with more than one
  process, swap in `connect-sqlite3` or `connect-redis`.
- **Single admin account.** There's one username/password pair, stored as
  a hash in `.env`. If you need multiple admins with their own logins
  later, that means adding a `users` table and extending `routes/auth.js`
  — happy to help with that when you're ready.
- **Department / role dropdowns** are still the fixed list from the
  mockup. If departments should be managed dynamically (added/renamed
  without touching code), that's a small additional table + admin screen.
- **Deploying to a server:** set real values in `.env` (especially
  `SESSION_SECRET` and `COOKIE_SECURE=true` once you're behind HTTPS),
  keep `data/` and `public/uploads/` on persistent storage (not always
  guaranteed on serverless platforms — a VPS, Render, Railway, or Fly.io
  with a persistent volume all work well for this SQLite setup).
