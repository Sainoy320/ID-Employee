// Generates a bcrypt hash for the admin password and prints the line to
// paste into your .env file. Run with: npm run set-password
const bcrypt = require("bcryptjs");
const readline = require("readline");

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

rl.question("Choose an admin password: ", (password) => {
  if (!password || password.length < 8) {
    console.error("\nPassword must be at least 8 characters. Try again.");
    rl.close();
    process.exit(1);
  }
  const hash = bcrypt.hashSync(password, 12);
  console.log("\nAdd this line to your .env file:\n");
  console.log(`ADMIN_PASSWORD_HASH=${hash}\n`);
  rl.close();
});
