const express = require("express");
const path = require("path");
const fs = require("fs");
const multer = require("multer");
const db = require("../db/database");
const requireAuth = require("../middleware/requireAuth");

const router = express.Router();

// ---------- Photo upload config ----------
const uploadsDir = path.join(__dirname, "..", "public", "uploads");
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${Date.now()}-${Math.round(Math.random() * 1e9)}${ext}`);
  },
});

function fileFilter(req, file, cb) {
  const allowed = [".jpg", ".jpeg", ".png"];
  const ext = path.extname(file.originalname).toLowerCase();
  if (!allowed.includes(ext)) {
    return cb(new Error("Only JPG or PNG photos are allowed."));
  }
  cb(null, true);
}

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
});

router.use(requireAuth);

// ---------- Helpers ----------
function nextEmployeeCode() {
  const year = new Date().getFullYear();
  const row = db.prepare("SELECT COUNT(*) AS n FROM employees").get();
  const seq = String(1000 + row.n + 1).slice(-4);
  return `GOV-${year}-${seq}`;
}

function serialize(row) {
  return {
    id: row.id,
    employeeCode: row.employee_code,
    firstName: row.first_name,
    lastName: row.last_name,
    fullName: `${row.first_name} ${row.last_name}`,
    age: row.age,
    dob: row.dob,
    pob: row.pob,
    municipality: row.municipality,
    department: row.department,
    role: row.role,
    phone: row.phone,
    email: row.email,
    startDate: row.start_date,
    status: row.status,
    photoUrl: row.photo_path ? `/uploads/${row.photo_path}` : null,
  };
}

// ---------- GET /api/employees ----------
// Supports ?search=&department=&status=&page=&pageSize=
router.get("/", (req, res) => {
  const { search = "", department = "", status = "" } = req.query;
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const pageSize = Math.min(Math.max(parseInt(req.query.pageSize, 10) || 10, 1), 100);

  const clauses = [];
  const params = {};

  if (search) {
    clauses.push(`(
      employee_code LIKE @search OR
      first_name LIKE @search OR
      last_name LIKE @search OR
      phone LIKE @search OR
      email LIKE @search
    )`);
    params.search = `%${search}%`;
  }
  if (department && department !== "All Departments") {
    clauses.push("department = @department");
    params.department = department;
  }
  if (status) {
    clauses.push("status = @status");
    params.status = status;
  }

  const where = clauses.length ? `WHERE ${clauses.join(" AND ")}` : "";

  const total = db.prepare(`SELECT COUNT(*) AS n FROM employees ${where}`).get(params).n;

  const rows = db
    .prepare(
      `SELECT * FROM employees ${where}
       ORDER BY created_at DESC
       LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset: (page - 1) * pageSize });

  res.json({
    employees: rows.map(serialize),
    pagination: { page, pageSize, total, totalPages: Math.max(Math.ceil(total / pageSize), 1) },
  });
});

// ---------- GET /api/employees/stats ----------
router.get("/stats", (req, res) => {
  const total = db.prepare("SELECT COUNT(*) AS n FROM employees").get().n;
  const active = db.prepare("SELECT COUNT(*) AS n FROM employees WHERE status = 'Active'").get().n;
  const departments = db.prepare("SELECT COUNT(DISTINCT department) AS n FROM employees").get().n;
  const newThisMonth = db
    .prepare(
      `SELECT COUNT(*) AS n FROM employees
       WHERE strftime('%Y-%m', start_date) = strftime('%Y-%m', 'now')`
    )
    .get().n;

  res.json({ total, active, newThisMonth, departments });
});

// ---------- GET /api/employees/export ----------
router.get("/export", (req, res) => {
  const rows = db.prepare("SELECT * FROM employees ORDER BY last_name, first_name").all();
  const header = [
    "Employee ID", "First Name", "Last Name", "Department", "Position",
    "Status", "Email", "Phone", "Start Date",
  ];
  const escape = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const lines = [header.join(",")];
  for (const r of rows) {
    lines.push(
      [r.employee_code, r.first_name, r.last_name, r.department, r.role, r.status, r.email, r.phone, r.start_date]
        .map(escape)
        .join(",")
    );
  }
  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", "attachment; filename=employee-directory.csv");
  res.send(lines.join("\n"));
});

// ---------- GET /api/employees/departments ----------
router.get("/departments", (req, res) => {
  const rows = db.prepare("SELECT DISTINCT department FROM employees ORDER BY department").all();
  res.json({ departments: rows.map((r) => r.department) });
});

// ---------- GET /api/employees/next-code ----------
router.get("/next-code", (req, res) => {
  res.json({ employeeCode: nextEmployeeCode() });
});

// ---------- GET /api/employees/:id ----------
router.get("/:id", (req, res) => {
  const row = db.prepare("SELECT * FROM employees WHERE id = ?").get(req.params.id);
  if (!row) return res.status(404).json({ error: "Employee not found." });
  res.json(serialize(row));
});

// ---------- POST /api/employees ----------
router.post("/", upload.single("photo"), (req, res) => {
  const b = req.body;

  if (!b.firstName || !b.lastName || !b.department || !b.role) {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.status(400).json({ error: "First name, last name, department, and role are required." });
  }

  const employeeCode = nextEmployeeCode();

  const stmt = db.prepare(`
    INSERT INTO employees
      (employee_code, first_name, last_name, age, dob, pob, municipality,
       department, role, phone, email, start_date, status, photo_path)
    VALUES
      (@employee_code, @first_name, @last_name, @age, @dob, @pob, @municipality,
       @department, @role, @phone, @email, @start_date, @status, @photo_path)
  `);

  const info = stmt.run({
    employee_code: employeeCode,
    first_name: b.firstName,
    last_name: b.lastName,
    age: b.age ? Number(b.age) : null,
    dob: b.dob || null,
    pob: b.pob || null,
    municipality: b.municipality || null,
    department: b.department,
    role: b.role,
    phone: b.phone || null,
    email: b.email || null,
    start_date: b.startDate || null,
    status: b.status || "Active",
    photo_path: req.file ? req.file.filename : null,
  });

  const row = db.prepare("SELECT * FROM employees WHERE id = ?").get(info.lastInsertRowid);
  res.status(201).json(serialize(row));
});

// ---------- PUT /api/employees/:id ----------
router.put("/:id", upload.single("photo"), (req, res) => {
  const existing = db.prepare("SELECT * FROM employees WHERE id = ?").get(req.params.id);
  if (!existing) {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.status(404).json({ error: "Employee not found." });
  }

  const b = req.body;
  let photoPath = existing.photo_path;
  if (req.file) {
    if (existing.photo_path) {
      const oldPath = path.join(uploadsDir, existing.photo_path);
      if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
    }
    photoPath = req.file.filename;
  }

  db.prepare(`
    UPDATE employees SET
      first_name = @first_name, last_name = @last_name, age = @age, dob = @dob,
      pob = @pob, municipality = @municipality, department = @department,
      role = @role, phone = @phone, email = @email, start_date = @start_date,
      status = @status, photo_path = @photo_path, updated_at = datetime('now')
    WHERE id = @id
  `).run({
    id: req.params.id,
    first_name: b.firstName ?? existing.first_name,
    last_name: b.lastName ?? existing.last_name,
    age: b.age !== undefined ? (b.age ? Number(b.age) : null) : existing.age,
    dob: b.dob ?? existing.dob,
    pob: b.pob ?? existing.pob,
    municipality: b.municipality ?? existing.municipality,
    department: b.department ?? existing.department,
    role: b.role ?? existing.role,
    phone: b.phone ?? existing.phone,
    email: b.email ?? existing.email,
    start_date: b.startDate ?? existing.start_date,
    status: b.status ?? existing.status,
    photo_path: photoPath,
  });

  const row = db.prepare("SELECT * FROM employees WHERE id = ?").get(req.params.id);
  res.json(serialize(row));
});

// ---------- DELETE /api/employees/:id ----------
router.delete("/:id", (req, res) => {
  const existing = db.prepare("SELECT * FROM employees WHERE id = ?").get(req.params.id);
  if (!existing) return res.status(404).json({ error: "Employee not found." });

  if (existing.photo_path) {
    const p = path.join(uploadsDir, existing.photo_path);
    if (fs.existsSync(p)) fs.unlinkSync(p);
  }
  db.prepare("DELETE FROM employees WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
