const express = require("express");
const bcrypt = require("bcryptjs");

const router = express.Router();

router.post("/login", (req, res) => {
  const { username, password } = req.body || {};

  if (!username || !password) {
    return res.status(400).json({ error: "Username and password are required." });
  }

  const validUsername = process.env.ADMIN_USERNAME || "admin";
  const storedHash = process.env.ADMIN_PASSWORD_HASH;

  if (!storedHash) {
    return res.status(500).json({
      error: "Server has no admin password configured. Run `npm run set-password` and set ADMIN_PASSWORD_HASH in .env.",
    });
  }

  if (username !== validUsername || !bcrypt.compareSync(password, storedHash)) {
    return res.status(401).json({ error: "Invalid username or password." });
  }

  req.session.user = { username };
  res.json({ ok: true, username });
});

router.post("/logout", (req, res) => {
  req.session.destroy(() => {
    res.clearCookie("connect.sid");
    res.json({ ok: true });
  });
});

router.get("/me", (req, res) => {
  if (req.session && req.session.user) {
    return res.json({ user: req.session.user });
  }
  res.status(401).json({ user: null });
});

module.exports = router;
