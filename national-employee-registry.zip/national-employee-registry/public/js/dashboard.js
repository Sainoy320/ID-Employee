// Wires dashboard.html up to the real backend: stats, the employee table
// (search + department filter + pagination), and row edit/delete actions.

const state = { search: "", department: "", page: 1, pageSize: 10 };

const tbody = document.getElementById("employee-rows");
const searchInput = document.getElementById("search-input");
const departmentFilter = document.getElementById("department-filter");
const paginationControls = document.getElementById("pagination-controls");
const paginationSummary = document.getElementById("pagination-summary");

function initials(firstName, lastName) {
  return `${(firstName || "?")[0]}${(lastName || "?")[0]}`.toUpperCase();
}

function statusClass(status) {
  if (status === "Active") return "status-active";
  if (status === "On Leave") return "status-leave";
  return "status-pending";
}

async function loadStats() {
  const res = await fetch("/api/employees/stats");
  if (!res.ok) return;
  const s = await res.json();
  document.getElementById("stat-total").textContent = s.total.toLocaleString();
  document.getElementById("stat-active").textContent = s.active.toLocaleString();
  document.getElementById("stat-new").textContent = s.newThisMonth.toLocaleString();
  document.getElementById("stat-departments").textContent = s.departments.toLocaleString();
}

async function loadDepartments() {
  const res = await fetch("/api/employees/departments");
  if (!res.ok) return;
  const { departments } = await res.json();
  departmentFilter.innerHTML =
    `<option value="">All Departments</option>` +
    departments.map((d) => `<option value="${d}">${d}</option>`).join("");
}

async function loadEmployees() {
  const qs = new URLSearchParams({
    search: state.search,
    department: state.department,
    page: state.page,
    pageSize: state.pageSize,
  });

  const res = await fetch(`/api/employees?${qs.toString()}`);
  if (!res.ok) return;
  const { employees, pagination } = await res.json();

  renderTable(employees);
  renderPagination(pagination);
}

function renderTable(employees) {
  if (employees.length === 0) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="9">No employee records match your search.</td></tr>`;
    return;
  }

  tbody.innerHTML = employees
    .map(
      (e) => `
    <tr>
      <td>
        <div class="table-avatar">
          ${e.photoUrl ? `<img src="${e.photoUrl}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:16px;">` : initials(e.firstName, e.lastName)}
        </div>
      </td>
      <td>${e.employeeCode}</td>
      <td class="name-cell">${e.fullName}</td>
      <td class="dept-cell">${e.department}</td>
      <td>${e.role}</td>
      <td><span class="status-pill ${statusClass(e.status)}">${e.status}</span></td>
      <td>${e.email || "—"}</td>
      <td>${e.startDate || "—"}</td>
      <td>
        <div class="row-actions">
          <button class="action-btn edit-btn" title="Edit" data-id="${e.id}">${ICONS.edit}</button>
          <button class="action-btn delete delete-btn" title="Delete" data-id="${e.id}" data-name="${e.fullName}">${ICONS.trash}</button>
        </div>
      </td>
    </tr>
  `
    )
    .join("");

  tbody.querySelectorAll(".edit-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      window.location.href = `add-employee.html?id=${btn.dataset.id}`;
    });
  });

  tbody.querySelectorAll(".delete-btn").forEach((btn) => {
    btn.addEventListener("click", () => handleDelete(btn.dataset.id, btn.dataset.name));
  });
}

function renderPagination({ page, totalPages, total, pageSize }) {
  const start = total === 0 ? 0 : (page - 1) * pageSize + 1;
  const end = Math.min(page * pageSize, total);
  paginationSummary.innerHTML = `Showing <strong>${start}-${end}</strong> of <strong>${total.toLocaleString()}</strong> employee profiles`;

  let html = `<button class="page-btn" id="prev-page" ${page <= 1 ? "disabled" : ""}>‹</button>`;
  for (let p = 1; p <= totalPages; p++) {
    if (p === 1 || p === totalPages || Math.abs(p - page) <= 1) {
      html += `<button class="page-btn ${p === page ? "current" : ""}" data-page="${p}">${p}</button>`;
    } else if (p === page - 2 || p === page + 2) {
      html += `<span class="ellipsis">...</span>`;
    }
  }
  html += `<button class="page-btn" id="next-page" ${page >= totalPages ? "disabled" : ""}>›</button>`;
  paginationControls.innerHTML = html;

  paginationControls.querySelectorAll("[data-page]").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.page = Number(btn.dataset.page);
      loadEmployees();
    });
  });
  const prevBtn = document.getElementById("prev-page");
  const nextBtn = document.getElementById("next-page");
  if (prevBtn) prevBtn.addEventListener("click", () => { state.page--; loadEmployees(); });
  if (nextBtn) nextBtn.addEventListener("click", () => { state.page++; loadEmployees(); });
}

async function handleDelete(id, name) {
  if (!confirm(`Remove ${name} from the registry? This cannot be undone.`)) return;
  const res = await fetch(`/api/employees/${id}`, { method: "DELETE" });
  if (res.ok) {
    loadEmployees();
    loadStats();
    loadDepartments();
  } else {
    alert("Could not delete this record.");
  }
}

let searchTimer;
searchInput.addEventListener("input", () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => {
    state.search = searchInput.value.trim();
    state.page = 1;
    loadEmployees();
  }, 300);
});

departmentFilter.addEventListener("change", () => {
  state.department = departmentFilter.value;
  state.page = 1;
  loadEmployees();
});

document.getElementById("export-link").addEventListener("mousedown", () => {
  // No JS needed — this is a real GET link to /api/employees/export that
  // streams a CSV response. Left as a plain anchor tag.
});

document.addEventListener("DOMContentLoaded", () => {
  loadStats();
  loadDepartments();
  loadEmployees();

  fetch("/api/auth/me")
    .then((r) => r.json())
    .then((d) => {
      if (d.user) {
        document.getElementById("user-name").textContent = d.user.username;
        document.getElementById("user-avatar").textContent = d.user.username.slice(0, 2).toUpperCase();
      }
    })
    .catch(() => {});
});
