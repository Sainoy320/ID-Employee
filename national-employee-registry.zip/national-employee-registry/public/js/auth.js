// Handles the login form submission against the real /api/auth/login endpoint.

const loginForm = document.getElementById("login-form");
const loginMessage = document.getElementById("login-message");
const loginBtn = document.getElementById("login-btn");

if (loginForm) {
  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    loginMessage.classList.remove("visible");
    loginBtn.disabled = true;
    loginBtn.textContent = "Signing in…";

    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value;

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Login failed.");
      }

      window.location.href = "dashboard.html";
    } catch (err) {
      loginMessage.textContent = err.message;
      loginMessage.classList.add("visible");
      loginBtn.disabled = false;
      loginBtn.textContent = "Sign In to Secure Database";
    }
  });
}
