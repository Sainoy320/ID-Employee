// Included on every protected page. Redirects to the login page if there is
// no active session, and wires up the shared logout button.

(async function guard() {
  try {
    const res = await fetch("/api/auth/me");
    if (!res.ok) throw new Error("not authenticated");
  } catch {
    window.location.href = "index.html";
  }
})();

document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".logout-btn, .logout-button").forEach((btn) => {
    btn.addEventListener("click", async (e) => {
      e.preventDefault();
      await fetch("/api/auth/logout", { method: "POST" });
      window.location.href = "index.html";
    });
  });
});
