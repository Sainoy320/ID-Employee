// Powers add-employee.html for both creating a new record and editing an
// existing one (edit mode is triggered by ?id=<n> in the URL).

const form = document.getElementById("employee-form");
const formMessage = document.getElementById("form-message");
const submitBtn = document.getElementById("submit-btn");
const employeeIdField = document.getElementById("employeeId");
const photoLabel = document.getElementById("photo-label");

const params = new URLSearchParams(window.location.search);
const editId = params.get("id");

function showMessage(text, type = "error") {
  formMessage.textContent = text;
  formMessage.className = `form-message visible ${type}`;
}

async function init() {
  if (editId) {
    document.getElementById("page-title").textContent = "Edit Employee Record";
    document.getElementById("page-subtitle").textContent = "Update the certified profile for this employee.";
    submitBtn.textContent = "Save Changes";

    try {
      const res = await fetch(`/api/employees/${editId}`);
      if (!res.ok) throw new Error("Could not load this employee record.");
      const emp = await res.json();

      employeeIdField.value = emp.employeeCode;
      form.firstName.value = emp.firstName || "";
      form.lastName.value = emp.lastName || "";
      form.age.value = emp.age || "";
      form.dob.value = emp.dob || "";
      form.pob.value = emp.pob || "";
      form.municipality.value = emp.municipality || "";
      form.department.value = emp.department || "";
      form.role.value = emp.role || "";
      form.status.value = emp.status || "Active";
      form.phone.value = emp.phone || "";
      form.email.value = emp.email || "";
      form.startDate.value = emp.startDate || "";
      if (emp.photoUrl) photoLabel.textContent = "Photo on file (choose a new one to replace)";
    } catch (err) {
      showMessage(err.message);
    }
  } else {
    try {
      const res = await fetch("/api/employees/next-code");
      const data = await res.json();
      employeeIdField.value = data.employeeCode;
    } catch {
      employeeIdField.value = "Assigned on save";
    }
  }
}

document.getElementById("photo").addEventListener("change", (e) => {
  const file = e.target.files[0];
  photoLabel.textContent = file ? file.name : "Upload Photo";
});

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  formMessage.classList.remove("visible");
  submitBtn.disabled = true;
  const originalLabel = submitBtn.textContent;
  submitBtn.textContent = editId ? "Saving…" : "Submitting…";

  try {
    const formData = new FormData(form);
    const url = editId ? `/api/employees/${editId}` : "/api/employees";
    const method = editId ? "PUT" : "POST";

    // PUT with FormData works fine with fetch/multer, no method-override needed.
    const res = await fetch(url, { method, body: formData });
    const data = await res.json();

    if (!res.ok) throw new Error(data.error || "Could not save this record.");

    window.location.href = "dashboard.html";
  } catch (err) {
    showMessage(err.message);
    submitBtn.disabled = false;
    submitBtn.textContent = originalLabel;
  }
});

init();
